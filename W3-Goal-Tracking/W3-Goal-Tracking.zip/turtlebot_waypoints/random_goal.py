import rclpy
from rclpy.node import Node
import numpy as np
from math import pi, atan2, cos, sin, sqrt
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

class path_planner(Node):
    def __init__(self):
        super().__init__("Turtlebot")
        self.x= 0.0
        self.y= 0.0
        self.theta = 0.0
        # Test goal:
        self.goal_x = 6
        self.goal_y = 6
        self.goal_theta = 3
        
        # # generate a random goal
        # self.goal_x = 10*np.random.random()
        # self.goal_y = 10*np.random.random()
        # self.goal_theta = normalize_angle(2*pi*np.random.random())
        self.get_logger().info(f"Initial Goal: {round(self.goal_x,2), round(self.goal_y, 2), round(360*self.goal_theta/pi, 4)}")

        # get position -> subscribe to the /odom topic
        self.sub_odom = self.create_subscription(Odometry,"/odom", self.get_odom, 10)

        # create a publisher to /cmd_vel
        self.cmd_vel = self.create_publisher(Twist, "/cmd_vel",10)

        # create our looping function
        self.loop_time = 0.01
        self.timer = self.create_timer(self.loop_time, self.loop)
        # generate our goal path for this waypoint
        self.goal_path = self.generate_path_to_goal()
        self.get_logger().info(f"Trajectory points: {self.goal_path}")

    def generate_goal(self):
        self.goal_x = 10*np.random.random()
        self.goal_y = 10*np.random.random()
        self.goal_theta = 2*pi*np.random.random()
    
    def generate_path_to_goal(self):
        '''Creates a path of 100 "waypoints" from initial position to final goal.
           Does this by finding trajectory from x_i,y_i to goal position, then generating
           a 2D array of x,y of points from this x_i, y_i to the goal'''
        C1 = 0.0
        x_dist = self.goal_x - self.x
        y_dist = self.goal_y - self.y
        traj = atan2(y_dist, x_dist) # trajectory
        path = [] # first, initialize an empty  list
        
        # datapoint ex:
        while C1 <= 1:
            x = self.x + C1*cos(traj)*x_dist
            y = self.y + C1*sin(traj)*y_dist
            path.append([x, y])
            C1 += 0.01
        return np.array(path)

    def convert_quaternion(self,x,y,z,w):
        ''' converts quaternions into the angle for z'''
        return atan2(2*(w*z+x*y), 1-2*(y**2 + z**2))

    def calculate_angular_velocity(self, lookahead_distance, x_goal, y_goal, linear_vel):
        '''Calculates curvature, and then returns the desired angular velocity to reach the lookahead time.'''
        x_dist_lookahead = x_goal - self.x
        y_dist_lookahead = y_goal - self.y
        angle_to_lookahead = atan2(y_dist_lookahead, x_dist_lookahead) - self.theta
        # prints just to double check the logic.
        self.get_logger().info(f"angle from current orientation (deg ): {(180/pi)*angle_to_lookahead} ")

        lateral_distance = sin(angle_to_lookahead)*sqrt(x_dist_lookahead**2 + y_dist_lookahead**2)
        curvature = 2*lateral_distance/lookahead_distance**2
        return curvature * linear_vel

    def get_odom(self, odometry_msg):
        ''' Updates the current x y position of the robot
            and prints a rounded value of the x y position.'''
        self.x = odometry_msg.pose.pose.position.x
        self.y = odometry_msg.pose.pose.position.y
        # orientation (quaternion)
        self.theta = self.convert_quaternion(odometry_msg.pose.pose.orientation.x, 
                                odometry_msg.pose.pose.orientation.y, 
                                odometry_msg.pose.pose.orientation.z,
                                odometry_msg.pose.pose.orientation.w)
        self.get_logger().info(f" Turtlebot Position (X,Y, theta): {round(self.x, 3), round(self.y,3), round(self.theta,3)},") # implement theta later

    def loop(self):
        '''Pure Pursuit Controller'''
        # first, find lookahead distance & planned path
        lookahead_dist = 1.0 # tunable lookahead distance
        msg = Twist()
        linear_vel = .5
        msg.linear.x = linear_vel

        if sqrt((self.x - self.goal_x)**2 + (self.y - self.goal_y)**2) >= 0.1:
            for i in range(len(self.goal_path)-1):
                # loop through goal paths and current positions, 
                # finding the lowest point which is > than lookahead distance
                x_path = self.goal_path[i,0]
                y_path = self.goal_path[i,1]
                dist_path = sqrt( (x_path-self.x)**2 + (y_path - self.y)**2)
                self.get_logger().info(f"Robot distance from pursuit point:{dist_path}")

                if dist_path >= lookahead_dist:
                    # finds the first point in path larger than lookahead dist
                    self.goal_path = self.goal_path[i:,:]
                    self.pursuit_x = self.goal_path[i,0]
                    self.pursuit_y = self.goal_path[i,1]
                    self.get_logger().info(f"Pursuing the point: {round(self.pursuit_x, 3), round(self.pursuit_y,3)}" )
                    break
            # find goal trajectory:
            self.theta_approach = normalize_angle(atan2(self.pursuit_y - self.y, self.pursuit_x - self.x))
            msg.angular.z = self.calculate_angular_velocity(lookahead_dist, self.pursuit_x, self.pursuit_y, linear_vel)
        else: # if our distance becomes within the error threshold
            msg.linear.x = 0.0
            msg.angular.z = 2.0
            self.get_logger().info(f"reached positional goal!")
            if (self.theta - self.goal_theta) <= 0.1:
                msg.angular.z = 0.0
                self.get_logger().info(f"reached angular goal!")

                # Generate a new goal
                self.generate_goal()
                self.goal_path = self.generate_path_to_goal()
                self.get_logger().info(f"New Goal Generated: {round(self.goal_x,3), round(self.goal_y,3), round(self.goal_theta,3)}")

        self.cmd_vel.publish(msg=msg)


def normalize_angle(angle):
        '''Normalizes angle between -pi to pi'''
        return (angle + pi) % (2*pi) - pi 

def main():
    rclpy.init()
    chaser = path_planner()
    rclpy.spin(chaser)
    rclpy.shutdown()
    